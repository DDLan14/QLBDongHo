package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;

import bean.hoadonbean;
import bean.khachhangbean;

public class hoadondao {
	ArrayList<hoadonbean> dshoadon= new ArrayList<hoadonbean>();
	public ArrayList<hoadonbean> gethd(String key){
		   try {
			 //B1 Ket noi csdl
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				String sql="select * from hoadon";
				PreparedStatement cmd= cs.cn.prepareStatement(sql);
				ResultSet rs= cmd.executeQuery();
				//B3 Duyet qua du lieu va lay ve
				while(rs.next()) {
					String mahd=rs.getString("MaHoaDon");
					String makh=rs.getString("makh");
					java.sql.Date ngaymua=rs.getDate("NgayMua");
					boolean damua=rs.getBoolean("damua");
					hoadonbean hd=new hoadonbean(makh, ngaymua, damua);
					hd.setMahd(mahd);
					if(key.equals(makh))
					{
						dshoadon.add(hd);
					}
				}
				//B4 Dong rs vaf cn
				rs.close();
				cs.cn.close();
				return dshoadon;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} 
	   }
	
	public void addhd(hoadonbean hd){
		   try {
			 //B1 Ket noi csdl
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				
				PreparedStatement stmt = cs.cn.prepareStatement("INSERT INTO hoadon(makh, NgayMua, damua) VALUES (?, ?, ?)");

				stmt.setInt(1, Integer.parseInt(hd.getMakh()));
				stmt.setDate(2, hd.getNgayMua());
				stmt.setBoolean(3, true);
				

				stmt.executeUpdate();
				//ResultSet rs= stmt.executeQuery();
				//B4 Dong rs vaf cn
				//rs.close();
				cs.cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	   }
	public String gethoadon1(){
		try {
			//B1 Ket noi csdl
			CoSodao cs= new CoSodao();
			cs.ketnoi();
			//B2 lay du lieu ve
			String sql="select * from hoadon where MaHoaDon= (select MAX(MaHoaDon) from hoadon)";
			PreparedStatement cmd= cs.cn.prepareStatement(sql);
			ResultSet rs= cmd.executeQuery();
			String MaHoaDon = null;
			//B3 Duyet qua du lieu va lay ve
			if(rs.next()) {
				MaHoaDon=rs.getString("MaHoaDon");
			}
			//B4 Dong rs vaf cn
			rs.close();
			cs.cn.close();
			return MaHoaDon;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
}
