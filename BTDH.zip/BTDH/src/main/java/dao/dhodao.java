package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bean.loaibean;
import bean.dhobean;

public class dhodao {
	
	ArrayList<dhobean> dsdho= new ArrayList<dhobean>();
	   public ArrayList<dhobean> getdho(){
		   try {
			 //B1 Ket noi csdl
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				String sql="select * from dongho";
				PreparedStatement cmd= cs.cn.prepareStatement(sql);
				ResultSet rs= cmd.executeQuery();
				//B3 Duyet qua du lieu va lay ve
				while(rs.next()) {
					String madh=rs.getString("madh");
					String tendh=rs.getString("tendh");
					String hangsp=rs.getString("hangsp");
					long soluong=rs.getLong("soluong");
					long gia=rs.getLong("gia");;
					String anh=rs.getString("anh");
					String maloai=rs.getString("maloai");
					dsdho.add(new dhobean(madh, tendh, hangsp, soluong, gia, anh, maloai));
				}
				//B4 Dong rs vaf cn
				rs.close();
				cs.cn.close();
				return dsdho;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	   }
	public ArrayList<dhobean> TimMa(String maloai)
	{	
		ArrayList<dhobean> tam = new ArrayList<dhobean>();
		ArrayList<dhobean> ds= getdho();
		for(dhobean s: ds)
		{
			if(s.getMaloai().equals(maloai))
				tam.add(s);
		}
		return tam;
	}
	public ArrayList<dhobean> Tim(String key)
	{	
		ArrayList<dhobean> tam = new ArrayList<dhobean>();
		ArrayList<dhobean> ds= getdho();
		for(dhobean s: ds)
		{
			if(s.getTendh().toLowerCase().trim().contains(key.toLowerCase().trim()) || 
					s.getMaloai().toLowerCase().trim().contains(key.toLowerCase().trim()) || 
					s.getHangsp().toLowerCase().trim().contains(key.toLowerCase().trim()))
				tam.add(s);
		}
		return tam;
	}
	public dhobean Timdho(String key)
	{
		ArrayList<dhobean> ds= getdho();
		dhobean sb = new dhobean();
		for(dhobean s: ds)
		{
			if(s.getMadh().equals(key))
				sb = s;
		}
		return sb;
	}
	public void adddho(dhobean s){
		   try {
			 //B1 Ket noi csdl
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				PreparedStatement stmt = cs.cn.prepareStatement("INSERT INTO dongho(madh, tendh, soluong,gia,maloai,anh,NgayNhap,hangsp) VALUES (?, ?, ? , ? , ?,?,?,?)");

				stmt.setString(1, s.getMadh());
				stmt.setString(2, s.getTendh());
				stmt.setLong(3, s.getSoluong());
				stmt.setLong(4, s.getGia());
				stmt.setString(5, s.getMaloai());
				stmt.setString(6, s.getAnh());
				stmt.setString(7,null);
				stmt.setString(8, s.getHangsp());
				stmt.executeUpdate();
				//B4 Dong rs vaf cn
				cs.cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	  }
	public void xoadho(String madh)
	{
		try {
				CoSodao cs = new CoSodao();
				cs.ketnoi();
				PreparedStatement stmt = cs.cn.prepareStatement("delete from dongho where madh=?");
				
				stmt.setString(1,madh);
				stmt.executeUpdate();
				cs.cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void update(dhobean sb) {
		try {
			CoSodao cs= new CoSodao();
			cs.ketnoi();
			//B2 lay du lieu ve
			PreparedStatement stmt = cs.cn.prepareStatement("update dongho set tendh= ?, soluong=? , gia=?, maloai=?, hangsp=? where madh=?");				
			stmt.setString(1, sb.getTendh());
			stmt.setLong(2, sb.getSoluong());
			stmt.setLong(3, sb.getGia());
			stmt.setString(4, sb.getMaloai());
			stmt.setString(5, sb.getHangsp());
			stmt.setString(7, sb.getMadh());
			stmt.executeUpdate();
			//ResultSet rs= stmt.executeQuery();
			//B4 Dong rs vaf cn
			//rs.close();
			cs.cn.close();
			
		} catch (Exception e) {
			e.printStackTrace();

		}
		
	}
}
