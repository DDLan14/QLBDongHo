package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bean.chitiethoadonbean;
import bean.hoadonbean;

public class chitiethoadondao {
	ArrayList<chitiethoadonbean> dschitiethd= new ArrayList<chitiethoadonbean>();
	public ArrayList<chitiethoadonbean> gethd(String key){
		   try {
			 //B1 Ket noi csdl
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				String sql="select * from ChiTietHoaDon";
				PreparedStatement cmd= cs.cn.prepareStatement(sql);
				ResultSet rs= cmd.executeQuery();
				//B3 Duyet qua du lieu va lay ve
				while(rs.next()) {
					String machitiethd=rs.getString("MaChiTietHD");
					String madh=rs.getString("MaDH");
					long soluong=rs.getLong("SoLuongMua");
					String mahd=rs.getString("MaHoaDon");
					boolean damua=rs.getBoolean("damua");
					chitiethoadonbean hd= new chitiethoadonbean(madh, soluong, mahd, true);
					hd.setMachitiethd(machitiethd);
					if(key.equals(mahd))
					{
						dschitiethd.add(hd);
					}
				}
				//B4 Dong rs vaf cn
				rs.close();
				cs.cn.close();
				return dschitiethd;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} 
	   }
	public void addcthd(chitiethoadonbean cthd){
		   try {
			 //B1 Ket noi csdl
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				PreparedStatement stmt = cs.cn.prepareStatement("INSERT INTO ChiTietHoaDon(MaDH, SoLuongMua, MaHoaDon, damua) VALUES (?, ?, ?, ?)");

				stmt.setString(1, cthd.getMadh());
				stmt.setLong(2, cthd.getSoluong());
				stmt.setString(3, cthd.getMahd());
				stmt.setBoolean(4, cthd.getDamua());
				

				stmt.executeUpdate();
				//ResultSet rs= stmt.executeQuery();
				//B4 Dong rs vaf cn
				//rs.close();
				cs.cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	   }
}
