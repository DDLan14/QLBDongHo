package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bean.dangnhapAdminbean;


public class dangnhapAdmindao {
	ArrayList<dangnhapAdminbean> dskhach= new ArrayList<dangnhapAdminbean>();
	   public dangnhapAdminbean getkh(String tendn, String pass){
		   try {
			 //B1 Ket noi csdl
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				String sql="select * from DangNhap where TenDangNhap=? and MatKhau=?";
				PreparedStatement cmd= cs.cn.prepareStatement(sql);
				cmd.setString(1, tendn);
				cmd.setString(2, pass);
				ResultSet rs= cmd.executeQuery();
				//B3 Duyet qua du lieu va lay ve
				dangnhapAdminbean dn=new dangnhapAdminbean();
				if(rs.next()) {//Dang nhap thanh cong
				 String TenDangNhap=rs.getString("TenDangNhap");
				 String MatKhau=rs.getString("MatKhau");
				 boolean Quyen=rs.getBoolean("Quyen");
				 dn=new dangnhapAdminbean(TenDangNhap, MatKhau, Quyen);
				}
				//B4 Dong rs vaf cn
				rs.close();
				cs.cn.close();
				return dn;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} 
	   }

	  
	  

}