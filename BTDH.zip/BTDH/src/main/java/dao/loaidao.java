package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.spi.DirStateFactory.Result;

import bean.loaibean;
import bean.dhobean;

public class loaidao {
	public ArrayList<loaibean> dsloai = new ArrayList<loaibean>();
	public ArrayList<loaibean> getloai(){
		try {
			//B1 Ket noi csdl
			CoSodao cs= new CoSodao();
			cs.ketnoi();
			//B2 lay du lieu ve
			String sql="select * from loai";
			PreparedStatement cmd= cs.cn.prepareStatement(sql);
			ResultSet rs= cmd.executeQuery();
			//B3 Duyet qua du lieu va lay ve
			while(rs.next()) {
				String maloai=rs.getString("maloai");
				String tenloai=rs.getString("tenloai");
				dsloai.add(new loaibean(maloai, tenloai));
			}
			//B4 Dong rs vaf cn
			rs.close();
			cs.cn.close();
			return dsloai;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
				
//		dsloai.add(new loaibean("tin","CÄ‚Â´ng nghĂ¡Â»â€¡ thÄ‚Â´ng tin"));
//		dsloai.add(new loaibean("ly","VĂ¡ÂºÂ­t lÄ‚Â½"));
//		dsloai.add(new loaibean("toan","ToÄ‚Â¡n Ă¡Â»Â©ng dĂ¡Â»Â¥ng"));
//		dsloai.add(new loaibean("van","VĂ„Æ’n hĂ¡Â»ï¿½c ViĂ¡Â»â€¡t Nam"));
//		return dsloai;

	}
	
	public void addloai(loaibean l){
		   try {
			 //B1 Ket noi csdl
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				PreparedStatement stmt = cs.cn.prepareStatement("INSERT INTO loai(maloai, tenloai) VALUES (?, ?)");
				stmt.setString(1, l.getMaloai());
				stmt.setString(2, l.getTenloai());

				stmt.executeUpdate();
				//ResultSet rs= stmt.executeQuery();
				//B4 Dong rs vaf cn
				//rs.close();
				cs.cn.close();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	  }
		public void xoaloai(String maloai)
		{
			try {
					CoSodao cs = new CoSodao();
					cs.ketnoi();
					PreparedStatement stmt = cs.cn.prepareStatement("delete from loai where maloai=?");
					
					stmt.setString(1,maloai);
					stmt.executeUpdate();
					cs.cn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		public loaibean Timloai(String key)
		{
			ArrayList<loaibean> ds= getloai();
			for(loaibean l: dsloai)
			{
				if(l.getMaloai().equals(key))
					return l;
			}
			return null;
		}
	   
		
	   public static void update(loaibean lb) {
			try {
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				PreparedStatement stmt = cs.cn.prepareStatement("update loai set tenloai=? where maloai=?");				
				stmt.setString(1, lb.getTenloai());
				stmt.setString(2, lb.getMaloai());
				stmt.executeUpdate();
				//ResultSet rs= stmt.executeQuery();
				//B4 Dong rs vaf cn
				//rs.close();
				cs.cn.close();
				
			} catch (Exception e) {
				e.printStackTrace();

			}
			
		}
}