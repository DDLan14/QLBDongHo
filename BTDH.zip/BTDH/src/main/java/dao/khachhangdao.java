package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bean.khachhangbean;

public class khachhangdao {
	ArrayList<khachhangbean> dskhach= new ArrayList<khachhangbean>();
	public ArrayList<khachhangbean> getkh(){
		   try {
			 //B1 Ket noi csdl
				CoSodao cs= new CoSodao();
				cs.ketnoi();
				//B2 lay du lieu ve
				String sql="select * from KhachHang";
				PreparedStatement cmd= cs.cn.prepareStatement(sql);
				ResultSet rs= cmd.executeQuery();
				//B3 Duyet qua du lieu va lay ve
				while(rs.next()) {
					String makh=rs.getString("makh");
					String hoten=rs.getString("hoten");
					String diachi=rs.getString("diachi");
					String sodt=rs.getString("sodt");
					String email=rs.getString("email");
					String tendn=rs.getString("tendn");
					String pass=rs.getString("pass");
					khachhangbean kh=new khachhangbean( hoten, diachi, sodt, email, tendn, pass);
					kh.setMakh(makh);
					dskhach.add(kh);
				}
				//B4 Dong rs vaf cn
				rs.close();
				cs.cn.close();
				return dskhach;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} 
	   }
		   public void addkh(khachhangbean kh){
			   try {
				 //B1 Ket noi csdl
					CoSodao cs= new CoSodao();
					cs.ketnoi();
					//B2 lay du lieu ve
					PreparedStatement stmt = cs.cn.prepareStatement("INSERT INTO KhachHang(hoten, diachi, sodt,email,tendn,pass) VALUES (?, ?, ? , ? , ?, ?)");

					stmt.setString(1, kh.getHoten());
					stmt.setString(2, kh.getDiachi());
					stmt.setString(3, kh.getSodt());
					stmt.setString(4, kh.getEmail());
					stmt.setString(5, kh.getTendn());
					stmt.setString(6, kh.getPass());
					

					stmt.executeUpdate();
					//ResultSet rs= stmt.executeQuery();
					//B4 Dong rs vaf cn
					//rs.close();
					cs.cn.close();
			} catch (Exception e) {
				e.printStackTrace();
			} 
		   }
}
