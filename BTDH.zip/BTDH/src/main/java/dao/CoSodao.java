package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CoSodao {
	public static Connection cn;
	public void ketnoi() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String st="jdbc:sqlserver://DESKTOP-FF1278R\\BOP:1433;databaseName=QlDongHo;user=sa; password=123"
					+";integratedSecurity=false;encrypt=false;trustServerCertificate=true";
			cn = DriverManager.getConnection(st);
			if(cn!=null) {
				System.out.println("ket noi thanh cong");
			}
			else {
				System.out.println("ket noi that bai");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
