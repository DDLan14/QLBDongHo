package bean;

public class dhobean {
	private String madh;
	private String tendh;
	private String hangsp;
	private long soluong;
	private long gia;
	private String anh;
	private String maloai;

	public dhobean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public dhobean(String madh, String tendh, String hangsp, long soluong, long gia, String anh, String maloai) {
		super();
		this.madh = madh;
		this.tendh = tendh;
		this.hangsp = hangsp;
		this.soluong = soluong;
		this.gia = gia;
		this.anh = anh;
		this.maloai = maloai;
	}
	public String getMadh() {
		return madh;
	}
	public void setMadh(String madh) {
		this.madh = madh;
	}
	public String getTendh() {
		return tendh;
	}
	public void setTendh(String tendh) {
		this.tendh = tendh;
	}
	public String getHangsp() {
		return hangsp;
	}
	public void setHangsp(String hangsp) {
		this.hangsp = hangsp;
	}
	public long getSoluong() {
		return soluong;
	}
	public void setSoluong(long soluong) {
		this.soluong = soluong;
	}
	public long getGia() {
		return gia;
	}
	public void setGia(long gia) {
		this.gia = gia;
	}
	public String getAnh() {
		return anh;
	}
	public void setAnh(String anh) {
		this.anh = anh;
	}
	public String getMaloai() {
		return maloai;
	}
	public void setMaloai(String maloai) {
		this.maloai = maloai;
	}
	
}
