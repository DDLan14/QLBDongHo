package bean;

public class giohangbean {
	private String madh;
	private String tendh;
	private long soluong;
	private long gia;
	private String anh;
	private long thanhtien;
	public giohangbean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public giohangbean(String madh, String tendh, long soluong, long gia, String anh) {
		super();
		this.madh = madh;
		this.tendh = tendh;
		this.soluong = soluong;
		this.gia = gia;
		this.anh = anh;
		this.thanhtien = soluong*gia;
	}
	public String getMadh() {
		return madh;
	}
	public void setMadh(String madh) {
		this.madh = madh;
	}
	public String getTendh() {
		return tendh;
	}
	public void setTendh(String tendh) {
		this.tendh = tendh;
	}
	public long getSoluong() {
		return soluong;
	}
	public void setSoluong(long soluong) {
		this.soluong = soluong;
	}
	public long getGia() {
		return gia;
	}
	public void setGia(long gia) {
		this.gia = gia;
	}
	public String getAnh() {
		return anh;
	}
	public void setAnh(String anh) {
		this.anh = anh;
	}
	public long getThanhtien() {
		return soluong*gia;
	}
	public void setThanhtien(long thanhtien) {
		this.thanhtien = thanhtien;
	}
	
}
