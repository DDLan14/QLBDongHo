package bo;

import java.util.ArrayList;

import bean.loaibean;
import bean.dhobean;
import dao.loaidao;

public class loaibo {
	loaidao ldao=new loaidao();
	ArrayList<loaibean> ds;
	public ArrayList<loaibean> getloai()
	{
		ds= ldao.getloai();
		return ds;
	}
	public void addloai(loaibean l) {
		ldao.addloai(l);
	 }
	 public void xoaloai(String maloai) {
			ldao.xoaloai(maloai);
		}
	 public loaibean timloai(String key)
		{
			return ldao.Timloai(key);
		}
	 public void sualoai(loaibean l) {
		 ldao.update(l);
	 }
}
