package bo;

import java.util.ArrayList;

import bean.dhobean;
import dao.dhodao;

public class dhobo {
	dhodao sdao = new dhodao();
	ArrayList<dhobean> ds;
	public ArrayList<dhobean> getdho(){
		ds = sdao.getdho();
		return ds;
	}
	public ArrayList<dhobean> TimMa(String maloai)
	{	
		ArrayList<dhobean> tam = new ArrayList<dhobean>();
		for(dhobean s: ds)
		{
			if(s.getMaloai().equals(maloai))
				tam.add(s);
		}
		return tam;
	}
	public ArrayList<dhobean> Tim(String key)
	{	
		ArrayList<dhobean> tam = new ArrayList<dhobean>();
		for(dhobean s: ds)
		{
			if(s.getTendh().toLowerCase().trim().contains(key.toLowerCase().trim()) || 
					s.getMaloai().toLowerCase().trim().contains(key.toLowerCase().trim()) || 
					s.getHangsp().toLowerCase().trim().contains(key.toLowerCase().trim()))
				tam.add(s);
		}
		return tam;
	}
	public void adddho(dhobean s) {
		sdao.adddho(s);
	 }
	public void xoadho(String madh) {
		sdao.xoadho(madh);
	}
	public dhobean timdho(String key)
	{
		return sdao.Timdho(key);
	}
	public void suadho(dhobean s) {
		 sdao.update(s);
	 }
}
