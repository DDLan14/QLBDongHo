package bo;

import java.util.ArrayList;

import bean.giohangbean;
import bean.hoadonbean;
import dao.hoadondao;

public class hoadonbo {
	hoadondao hddao = new hoadondao();
	ArrayList<hoadonbean> ds;
	public ArrayList<hoadonbean> gethd(String key){
		 ds=hddao.gethd(key);
		 return ds;
	 }
	 public void themhd(hoadonbean hd) {
		hddao.addhd(hd);
	 }
	 public String gethd1() {
		 return hddao.gethoadon1();
	 }
}
