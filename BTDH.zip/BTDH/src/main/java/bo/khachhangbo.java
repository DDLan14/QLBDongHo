package bo;

import java.util.ArrayList;

import dao.khachhangdao;
import dao.dhodao;
import bean.khachhangbean;
import bean.dhobean;

public class khachhangbo {
	khachhangdao khdao= new khachhangdao();
	 ArrayList<khachhangbean> ds;
	 public ArrayList<khachhangbean> getkh(){
		 ds=khdao.getkh();
		 return ds;
	 }
	 public void themkh(khachhangbean kh) {
		khdao.addkh(kh);
	 }
	 public khachhangbean Tim(String tendn){		   
		 khachhangbean tam = new khachhangbean();
		   for(khachhangbean s:ds) {
			   if(s.getTendn().equals(tendn))				   
				   return s;
		   }
		   return null;
	   }
	 public khachhangbean Tim2(String tendn, String matkhau){		   
		 khachhangbean tam = new khachhangbean();
		   for(khachhangbean s:ds) {
			   if((s.getTendn().equals(tendn))&&(s.getPass().equals(matkhau)))				   
				   return s;
		   }
		   return null;
	   }
}