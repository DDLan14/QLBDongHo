package bo;

import java.util.ArrayList;

import bean.xacnhanbean;
import dao.xacnhandao;

public class xacnhanbo {
  xacnhandao xndao= new xacnhandao();
  ArrayList<xacnhanbean> ds = new ArrayList<xacnhanbean>();
  public ArrayList<xacnhanbean> getdanhsach(){
	ds=xndao.getxacnhan();
	return ds;
  }
  public void xacnhanmua(String macthd) {
	  xndao.xacnhanmua(macthd);
	  for (xacnhanbean k : ds) {
		if(k.getMaChiTietHD().equals(macthd))
			ds.remove(k);
	}
	  
  }
}