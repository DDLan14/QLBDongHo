package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.dhobean;
import bo.loaibo;
import bo.dhobo;

/**
 * Servlet implementation class htdhoController
 */
@WebServlet("/htdhoController")
public class htdhoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public htdhoController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		loaibo loai=new loaibo();
		request.setAttribute("dsloai", loai.getloai());
		
		
		dhobo sdao= new dhobo();
		ArrayList<dhobean> dsdho = sdao.getdho();
		String maloai=request.getParameter("ml");
		String search = request.getParameter("txttk");
		if(maloai!=null)
			dsdho=sdao.TimMa(maloai);
		if(search != null)
			dsdho=sdao.Tim(search);
		int n=dsdho.size();
		request.setAttribute("dsdho", dsdho);
		request.setAttribute("soluong", n);
		
		
		
		RequestDispatcher rd = request.getRequestDispatcher("htdongho1.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
