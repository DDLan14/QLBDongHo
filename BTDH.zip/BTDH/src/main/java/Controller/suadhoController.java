package Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import bean.dhobean;
import bo.dhobo;
/**
 * Servlet implementation class suadhoController
 */
@WebServlet("/suadhoController")
public class suadhoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public suadhoController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		DiskFileItemFactory factory = new DiskFileItemFactory();
		DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(fileItemFactory);
		String madh = null;
		String tendh = null;
		long soluong = 0;
		long gia = 0;
		String maloai = null;
		String hangsp = null;
		try {
			List<FileItem> fileItems = upload.parseRequest(request);//Láº¥y vá»� cĂ¡c Ä‘á»‘i tÆ°á»£ng gá»­i lĂªn
			//duyá»‡t qua cĂ¡c Ä‘á»‘i tÆ°á»£ng gá»­i lĂªn tá»« client gá»“m file vĂ  cĂ¡c control
			for (FileItem fileItem : fileItems) {
				String tentk=fileItem.getFieldName();
				
				
				if(tentk.equals("madh")) madh=fileItem.getString();
				if(tentk.equals("tendh")) tendh = fileItem.getString();
				if(tentk.equals("soluong")) soluong = Long.parseLong(fileItem.getString());
				if(tentk.equals("gia")) gia = Long.parseLong(fileItem.getString());
				if(tentk.equals("maloai")) maloai = fileItem.getString();
				if(tentk.equals("hangsp")) hangsp = fileItem.getString();
				
			}
			response.getWriter().println(madh);
			dhobean sb= new dhobean(madh, tendh, hangsp, soluong, gia, null, maloai);
			dhobo sbo= new dhobo();
			sbo.suadho(sb);
			response.sendRedirect("themdhoController");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
