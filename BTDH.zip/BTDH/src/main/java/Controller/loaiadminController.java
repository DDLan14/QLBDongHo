package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.loaibean;
import bo.loaibo;

/**
 * Servlet implementation class loaiadminController
 */
@WebServlet("/loaiadminController")
public class loaiadminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loaiadminController() {
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String maloai=null;
		String tenloai=null;
		if(request.getParameter("maloai")!=null) {
			maloai=request.getParameter("maloai");
		}
		if(request.getParameter("tenloai")!=null) {
			tenloai=request.getParameter("tenloai");
		}
		if(request.getParameter("add")!=null) {
			loaibean lb= new loaibean(maloai,tenloai);
			loaibo lbo= new loaibo();
			lbo.addloai(lb);
			response.sendRedirect("themloaiController");
		}
		if(request.getParameter("edit")!=null) {
			loaibean lb= new loaibean(maloai,tenloai);
			loaibo lbo= new loaibo();
			lbo.sualoai(lb);
			response.sendRedirect("themloaiController");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}