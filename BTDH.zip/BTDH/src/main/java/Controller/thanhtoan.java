package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import bean.chitiethoadonbean;
import bean.giohangbean;
import bean.hoadonbean;
import bean.khachhangbean;
import bo.chitiethoadonbo;
import bo.giohangbo;
import bo.hoadonbo;

/**
 * Servlet implementation class thanhtoan
 */
@WebServlet("/thanhtoan")
public class thanhtoan extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public thanhtoan() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String Hoten = request.getParameter("txtht") ;
		String DiaChi = request.getParameter("txtdc");
		String Email = request.getParameter("txtemail");
		String SDT = request.getParameter("txtstd");
		
		chitiethoadonbo cthdbo = new chitiethoadonbo();
		
		
			HttpSession session = request.getSession();
			giohangbo gh = (giohangbo)session.getAttribute("gio");
			if(session.getAttribute("dn")==null)
			{
				response.sendRedirect("dangnhap");
			}
			
			khachhangbean kh = (khachhangbean) session.getAttribute("dn");
			long millis=System.currentTimeMillis(); 
			java.sql.Date ngaymua= new java.sql.Date(millis);
			boolean damua = true;
			hoadonbean hd = new hoadonbean(kh.getMakh(), ngaymua, damua);
			hoadonbo hdbo = new hoadonbo();
			hdbo.themhd(hd);
			String mhd =hdbo.gethd1();
			  for (giohangbean a : gh.ds) {
				  
				  chitiethoadonbean cthdbean= new chitiethoadonbean(a.getMadh(),a.getSoluong() ,mhd , false);
				  cthdbo.themhd(cthdbean);
			}
			
			session.removeAttribute("gio");
			
			response.sendRedirect("htdhoController");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
