package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bo.giohangbo;

/**
 * Servlet implementation class xoasua
 */
@WebServlet("/xoasua")
public class xoasua extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public xoasua() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		giohangbo gh=(giohangbo)session.getAttribute("gio");
		  String[] check= request.getParameterValues("check");
		  if(check!=null)
			  for(String mdh:check)
				try {
					gh.Xoa(mdh);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		  	session.setAttribute("i", gh.ds.size());
		  if(request.getParameter("butxoa")!=null){
			  String mdh=request.getParameter("butxoa");
			  try {
				gh.Xoa(mdh);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		  if(request.getParameter("butsua")!=null){
			  String mdh=request.getParameter("butsua");
			  String sl=request.getParameter(mdh);
			//  out.print(ms+":"+sl);
			  gh.Sua(mdh, "", Long.parseLong(sl), 0, "");
		  }
		  if(request.getParameter("butxoahet")!=null)
		  {
			  try {
				gh.Xoahet();
			} catch (Exception e) {
				// TODO: handle exception
			}
		  }
		  session.setAttribute("i", gh.ds.size());
		  session.setAttribute("gio", gh);
		  if(gh.ds.size()==0 || session.getAttribute("gio")==null){
			  session.removeAttribute("dn");
			  session.removeAttribute("gio");
			  session.setAttribute("i", 0);
			  
			  response.sendRedirect("htdhoController");
			  
		  }
		  else
		  {
			  response.sendRedirect("ghangController");
		  }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
